package com.loiane.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loiane.dao.ErrorDAO;
import com.loiane.model.Error;
import com.loiane.util.Util;

import net.sf.json.JSONObject;

/**
 * Contact Service
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@Service
public class ErrorService {
	
	private ErrorDAO errorDAO;
	private Util util;

	/**
	 * Get all contacts
	 * @return
	 */
	@Transactional(readOnly=true)
	public List<Error> getErrorList(){

		return errorDAO.getErrors();
	}
	
	/**
	 * Create new Contact/Contacts
	 * @param data - json data from request
	 * @return created contacts
	 */
	@Transactional
	public Error create(JSONObject data){
		
		Error newErrors = (Error)JSONObject.toBean(data,Error.class);
		errorDAO.saveError(newErrors);
		
		return newErrors;
	}
	
	
	/**
	 * Update contact/contacts
	 * @param data - json data from request
	 * @return updated contacts
	 */
	@Transactional
	public List<Error> update(Object data){
		
		List<Error> returnErrors = new ArrayList<Error>();
		
		List<Error> updatedErrors = util.getErrorsFromRequest(data);
		
		for (Error error : updatedErrors){
			returnErrors.add(errorDAO.saveError(error));
		}
		
		return returnErrors;
	}
	
	/**
	 * Delete contact/contacts
	 * @param data - json data from request
	 */
	@Transactional
	public void delete(Integer id){
		errorDAO.deleteError(id);
			
	}	

	/**
	 * Spring use - DI
	 * @param contactDAO
	 */
	@Autowired
	public void setErrorDAO(ErrorDAO errorDAO) {
		this.errorDAO = errorDAO;
	}

	/**
	 * Spring use - DI
	 * @param util
	 */
	@Autowired
	public void setUtil(Util util) {
		this.util = util;
	}
	
}
