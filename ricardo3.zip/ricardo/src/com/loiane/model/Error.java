package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * Contact POJO
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@JsonAutoDetect
@Entity
@Table(name="error")
public class Error {
	
	@Id
	@GeneratedValue
	@Column(name="e_id")
	private int e_id;
	private String e_error;
	private String e_desc;

	

	public int getId() {
		return e_id;
	}
	
	public void setId(int e_id) {
		this.e_id = e_id;
	}

	@Column(name="e_error", nullable=false)
	public String getError() {
		return e_error;
	}
	
	public void setError(String e_error) {
		this.e_error = e_error;
	}
	
	@Column(name="e_desc", nullable=false)
	public String getDesc() {
		return e_desc;
	}
	
	public void setDesc(String e_desc) {
		this.e_desc = e_desc;
	}	
}