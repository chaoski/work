package com.loiane.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * Contact POJO
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@JsonAutoDetect
@Entity
@Table(name="log")
public class Log {
	
	@Id
	@GeneratedValue
	@Column(name="l_id")
	private int l_id;
	private String l_name;
	
	@ManyToOne
	@JoinColumn(name="a_id")
	private App a_id;
	
	@ManyToOne
	@JoinColumn(name="e_id")
	private Error e_id;
	
	
	public int getId() {
		return l_id;
	}
	
	public void setId(int l_id) {
		this.l_id = l_id;
	}
	
	@Column(name="l_name", nullable=false)
	public String getName() {
		return l_name;
	}
	
	public void setName(String l_name) {
		this.l_name = l_name;
	}
	
	@Column(name="a_id", nullable=false)
	public App getAID() {
		return a_id;
	}
	
	public void setAID(App a_id) {
		this.a_id = a_id;
	}
	
	@Column(name="e_id", nullable=false)
	public Error getEID() {
		return e_id;
	}
	
	public void setEID(Error e_id) {
		this.e_id = e_id;
	}
	
	public Log() { 
	}
}

