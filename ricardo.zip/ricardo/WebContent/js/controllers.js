angular.module('appa.controllers',[])

//LOG//
.controller('logsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"log/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	$("#logbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].aid.name+"</td><td>"+data.data[i].eid.error+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving log list");
	      }
	  }); 
}])

//ERROR//
.controller('errorsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"error/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	$("#errorbody").append("<tr><td>"+data.data[i].error+"</td><td>"+data.data[i].desc+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving error list");
	      }
	  }); 
}])

//APP//
.controller('appsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"app/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	$("#appbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].desc+"</td><td>"+data.data[i].stat+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving app list");
	      }
	  }); 
	
	$scope.saveapp= function (){
		var adapp =$("#adapp").val();
		var adapdesc =$("#adapdesc").val();
		var adapst =$("#adapst").val();
		
		if(adapp!=""){
			$http({
				method: "POST",
				url: url+"app/create.action",
				data:{
			    	  name:adapp, 
			    	  desc:adapdesc, 
			    	  stat:adapst
			    	  },
			    contentType:"aplication/json",
				crossDomain: true,
			    async: true	     
				}).then(function successCallback(response){
					alert("app created");
			     },function successCallback(response){
			    	 alert("Error creating app");		     
			  }); 	
		} else	{
			alert("Empty fields");
		}
	}
}]);