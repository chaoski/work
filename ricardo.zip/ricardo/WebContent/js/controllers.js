angular.module('appa.controllers',[])

//LOG//
.controller('logsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"log/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
//	        	$("#logbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].aid.name+"</td><td>"+data.data[i].eid.error+"</td></tr>");
	        	$("#logbody").append("<tr><td>"+data.data[i].l_name+"</td><td>"+data.data[i].app+"</td><td>"+data.data[i].error+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving log list");
	      }
	}); 
//	dropdown app
	$.ajax({
	      url: url+"app/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
//	        	$("#logapp").append("<option value='"+data.data[i].id+"'>"+data.data[i].name+"</option>");
	        	$("#logapp").append("<option value='"+data.data[i].name+"'>"+data.data[i].name+"</option>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving app list");
	      }
	});
//	dropdown error
	$.ajax({
	      url: url+"error/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
//	        	$("#logerror").append("<option value='"+data.data[i].id+"'>"+data.data[i].error+"</option>");
	        	$("#logerror").append("<option value='"+data.data[i].error+"'>"+data.data[i].error+"</option>");
	        	$("#listerror").append("<option value='"+data.data[i].error+"'>"+data.data[i].error+"</option>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving error list");
	      }
	});
	
	$scope.savelog= function (){
		var user =$("#user").val();
		var lapp =$("#logapp").val();
		var lerror =$("#logerror").val()
		
		if(user!=""){
			$http({
				method: "POST",
				url: url+"log/create.action",
				data:{
			    	  name:user, 
			    	  app:lapp,
			    	  error:lerror
			    	  },
			    contentType:"aplication/json",
				crossDomain: true,
			    async: true	     
				}).then(function successCallback(response){
					alert("Log created");
					$.ajax({
					      url: url+"log/view.action",
					      type: "GET",
					      crossDomain: true,
					      async: true,
					      success: function(data) {
					    	  
					    	  var large = data.data.length;
						      $("#logbody").remove();
						      $("#logtable").append("<tbody id='logbody'></tbody")
						      for(i=0;i<large;i++){
						    	  $("#logbody").append("<tr><td>"+data.data[i].l_name+"</td><td>"+data.data[i].app+"</td><td>"+data.data[i].error+"</td></tr>");
						      }
					      },
					      error:function(){
					          alert("Error retrieving log list");
					      }
					});
			     },function successCallback(response){
			    	 alert("Error creating log");		     
			  }); 	
		} else	{
			alert("Empty fields");
		}
	}
	
//	$scope.savelog= function (){
//		var user =$("#user").val();
//		var lapp =$("#logapp").val();
//		var lerror =$("#logerror").val()
//		
//		if(user!=""){
//			$http({
//				method: "POST",
//				url: url+"log/create.action",
//				data:{
//			    	  name:user, 
//			    	  a_id:lapp,
//			    	  e_id:lerror
//			    	  },
//			    contentType:"aplication/json",
//				crossDomain: true,
//			    async: true	     
//				}).then(function successCallback(response){
//					alert("Log created");
//					$.ajax({
//					      url: url+"log/view.action",
//					      type: "GET",
//					      crossDomain: true,
//					      async: true,
//					      success: function(data) {
//					    	  
//					        var large = data.data.length;
//					        $("#logbody").remove();
//					        $("#logtable").append("<tbody id='logbody'></tbody")
//					        for(i=0;i<large;i++){
//					        	$("#logbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].aid.name+"</td><td>"+data.data[i].eid.error+"</td></tr>");
//					        }
//					      },
//					      error:function(){
//					          alert("Error retrieving log list");
//					      }
//					});
//			     },function successCallback(response){
//			    	 alert("Error creating log");		     
//			  }); 	
//		} else	{
//			alert("Empty fields");
//		}
//	}
//	$scope.savelog= function (){
//		var user =$("#user").val();
//		var logapp =$("#logapp").val();
//		var logerror =$("#logerror").val();
//		
//		if(user!=""){
//			$http({
//				method: "POST",
//				url: url+"log/create.action",
//				data:{
//					l_name:user, 
//					a_id:logapp,
//					e_id:logerror
//				},
//			    contentType:"aplication/json",
//				crossDomain: true,
//			    async: true	     
//				}).then(function successCallback(response){
//					alert("Log created");
//					$.ajax({
//					      url: url+"log/view.action",
//					      type: "GET",
//					      crossDomain: true,
//					      async: true,
//					      success: function(data) {
//					    	  var large = data.data.length;
//					    	  $("#logbody").remove();
//					    	  $("#logtable").append("<tbody id='logbody'></tbody>");
//					    	  for(i=0;i<large;i++){
//					    		  $("#logbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].aid.name+"</td><td>"+data.data[i].eid.error+"</td></tr>");
//					    	  }
//					      },
//					      error:function(){
//					    	  alert("Error retrieving log list");
//					      }
//					});					
//				},function successCallback(response){
//					alert("Error creating log");		     
//				}); 	
//		} else	{
//			alert("Empty fields");
//		}
//	}
}])

//ERROR//
.controller('errorsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"error/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	$("#errorbody").append("<tr><td>"+data.data[i].error+"</td><td>"+data.data[i].desc+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving error list");
	      }
	});
	
	$scope.saveerror= function (){
		var adercode =$("#adercode").val();
		var aderdesc =$("#aderdesc").val();
		
		if(adercode!="" && aderdesc!=""){
			$http({
				method: "POST",
				url: url+"error/create.action",
				data:{
			    	  error:adercode, 
			    	  desc:aderdesc
			    	  },
			    contentType:"aplication/json",
				crossDomain: true,
			    async: true	     
				}).then(function successCallback(response){
					alert("Error created");
					$.ajax({
					      url: url+"error/view.action",
					      type: "GET",
					      crossDomain: true,
					      async: true,
					      success: function(data) {
					    	  
					        var large = data.data.length;
					        $("#errorbody").remove();
					        $("#errortable").append("<tbody id='errorbody'></tbody>")
					        for(i=0;i<large;i++){
					        	$("#errorbody").append("<tr><td>"+data.data[i].error+"</td><td>"+data.data[i].desc+"</td></tr>");
					        }
					      },
					      error:function(){
					          alert("Error retrieving error list");
					      }
					});
			     },function successCallback(response){
			    	 alert("Error creating error");		     
			  }); 	
		} else	{
			alert("Empty fields");
		}
	}
	
	$scope.delerror= function (){
		
	}


}])

//APP//
.controller('appsctrl', ['$scope','$http',function($scope, $http) {
	
	var url = "http://localhost:8080/extjs-crud-grid-spring-hibernate/";
		
	$.ajax({
	      url: url+"app/view.action",
	      type: "GET",
	      crossDomain: true,
	      async: true,
	      success: function(data) {
	    	  
	        var large = data.data.length;
	      
	        for(i=0;i<large;i++){
	        	$("#appbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].desc+"</td><td>"+data.data[i].stat+"</td></tr>");
	        }
	      },
	      error:function(){
	          alert("Error retrieving app list");
	      }
	  }); 
	
	$scope.saveapp= function (){
		var adapp =$("#adapp").val();
		var adapdesc =$("#adapdesc").val();
		var adapst =$("#adapst").val();
		
		if(adapp!="" && adapdesc!=""){
			$http({
				method: "POST",
				url: url+"app/create.action",
				data:{
			    	  name:adapp, 
			    	  desc:adapdesc, 
			    	  stat:adapst
			    	  },
			    contentType:"aplication/json",
				crossDomain: true,
			    async: true	     
				}).then(function successCallback(response){
					alert("App created");			
					$.ajax({
					      url: url+"app/view.action",
					      type: "GET",
					      crossDomain: true,
					      async: true,
					      success: function(data) {
					    	  
					        var large = data.data.length;
					        $("#appbody").remove();
					        $("#apptable").append("<tbody id='appbody'></tbody>")
					        for(i=0;i<large;i++){
					        	$("#appbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].desc+"</td><td>"+data.data[i].stat+"</td></tr>");
					        }
					      },
					      error:function(){
					          alert("Error retrieving app list");
					      }
					  }); 					
			     },function successCallback(response){
			    	 alert("Error creating app");		     
			  }); 	
		} else	{
			alert("Empty fields");
		}
	}
}]);