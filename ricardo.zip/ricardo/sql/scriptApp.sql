DROP TABLE IF EXISTS `test`.`app`;
CREATE TABLE  `test`.`app` (
  `a_id` int NOT NULL AUTO_INCREMENT,
  `a_name` varchar(50) NOT NULL,
  `a_desc` varchar(100) NOT NULL,
  `a_stat` varchar(50) NOT NULL,
  PRIMARY KEY (`a_id`)
) 
ENGINE=InnoDB;

insert into app (a_name, a_desc, a_stat) values ('Word','Text editor', 'ACTIVE');
insert into app (a_name, a_desc, a_stat) values ('Excel','Table editor', 'ACTIVE');
insert into app (a_name, a_desc, a_stat) values ('Chrome','Web browser', 'ACTIVE');