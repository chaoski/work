DROP TABLE IF EXISTS `test`.`error`;
CREATE TABLE  `test`.`error` (
  `e_id` int NOT NULL AUTO_INCREMENT,
  `e_error` varchar(100) NOT NULL,
  `e_desc` varchar(100) NOT NULL,
  PRIMARY KEY (`e_id`)
) 
ENGINE=InnoDB;

insert into error (e_error, e_desc) values ('404', 'Server could not find what was requested');
insert into error (e_error, e_desc) values ('504', 'An error stating that a gateway timeout occurred in the internet link');