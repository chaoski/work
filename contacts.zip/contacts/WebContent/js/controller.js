angular.module('starter.controllers',[])

.controller('CtCtrl', ['$scope','$http',function($scope, $http) {

	var url = "http://localhost:8080/contacts/";
	
	$scope.Mostrar = function(){
		$.ajax({
		      url: url+"contact/view.action",
		      type: "GET",
		      crossDomain: true,
		      async: true,
		      success: function(data) {
		    	  
		        var large = data.data.length;		      
		        for(i=0;i<large;i++){		   
		        	
		        	$("#contactbody").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].email+"</td><td>"+data.data[i].phone+"</td></tr>");
		        }
		      },
		      error:function(){
		          alert("Error retrieving app list");
		      }
		  })
	};
}]);