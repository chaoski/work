package dao;

import java.util.List;
import model.Contact;

public interface IContactDAO {
	
	public List<Contact> getContacts();
	public void deleteContact(int id);
	public Contact saveContact(Contact contact);

}
