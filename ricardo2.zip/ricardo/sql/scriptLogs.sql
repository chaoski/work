DROP TABLE IF EXISTS `test`.`log`;
CREATE TABLE  `test`.`log` (
  `l_id` int NOT NULL AUTO_INCREMENT,
  `l_name` varchar(50) NOT NULL,
  `a_id` int NOT NULL,
  `e_id` int NOT NULL,
  PRIMARY KEY (`l_id`),
  constraint foreign key (a_id) references app (a_id),
  constraint foreign key (e_id) references error (e_id)
)
ENGINE=InnoDB;

insert into LOG (l_name, a_id, e_id) values ('Ricardo',3,2);
insert into LOG (l_name, a_id, e_id) values ('Daniel',3,1);