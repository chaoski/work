DROP TABLE IF EXISTS `test`.`log`;
CREATE TABLE  `test`.`log` (
  `l_id` int NOT NULL AUTO_INCREMENT,
  `l_name` varchar(50) NOT NULL,
  `app` varchar(50) NOT NULL,
  `error` varchar(50) NOT NULL,
  PRIMARY KEY (`l_id`)
)
ENGINE=InnoDB;

insert into LOG (l_name, app, error) values ('Ricardo', 'Word', '404');
insert into LOG (l_name, app, error) values ('Daniel', 'Chrome', '504');