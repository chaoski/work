package com.loiane.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.loiane.model.Log;
import com.loiane.service.LogService;

import net.sf.json.JSONObject;

/**
 * Controller - Spring
 * 
 * @author Loiane Groner
 * http://loianegroner.com (English)
 * http://loiane.com (Portuguese)
 */
@Controller
public class LogController  {

	private LogService logService;
	
	@RequestMapping(value="/log/view.action")
	public @ResponseBody Map<String,? extends Object> view() throws Exception {

		try{

			List<Log> log = logService.getLogList();

			return getMap(log);

		} catch (Exception e) {

			return getModelMapError("Error retrieving Logs from database.");
		}
	}
	
	@RequestMapping(value="/log/create.action")
	public @ResponseBody Map<String,? extends Object> create(@RequestBody JSONObject data) throws Exception {
		System.out.println(data);
		try{
			Log log = logService.create(data);

			return getMapLog(log);

		} catch (Exception e) {

			return getModelMapError("Error trying to create log.");
		}
	}
	
	@RequestMapping(value="/log/update.action")
	public @ResponseBody Map<String,? extends Object> update(@RequestParam Object data) throws Exception {
		try{

			List<Log> log = logService.update(data);

			return getMap(log);

		} catch (Exception e) {

			return getModelMapError("Error trying to update log.");
		}
	}
	
	@RequestMapping(value="/log/delete.action")
	public @ResponseBody Map<String,? extends Object> delete(@RequestParam Object data) throws Exception {
		
		try{

			logService.delete(data);

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			modelMap.put("success", true);

			return modelMap;

		} catch (Exception e) {

			return getModelMapError("Error trying to delete log.");
		}
	}
	
	/**
	 * Generates modelMap to return in the modelAndView
	 * @param logs
	 * @return
	 */
	private Map<String,Object> getMap(List<Log> log){
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		modelMap.put("total", log.size());
		modelMap.put("data", log);
		modelMap.put("success", true);
		
		return modelMap;
	}
	
	private Map<String,Object> getMapLog(Object log){
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		modelMap.put("total", 1);
		modelMap.put("data", log);
		modelMap.put("success", true);
		
		return modelMap;
	}	
	/**
	 * Generates modelMap to return in the modelAndView in case
	 * of exception
	 * @param msg message
	 * @return
	 */
	private Map<String,Object> getModelMapError(String msg){

		Map<String,Object> modelMap = new HashMap<String,Object>(2);
		modelMap.put("message", msg);
		modelMap.put("success", false);

		return modelMap;
	} 

	@Autowired
	public void setLogService(LogService logService) {
		this.logService = logService;
	}

}
